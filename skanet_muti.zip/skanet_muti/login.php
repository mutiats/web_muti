<?php
include "koneksi.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login Dashboard</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f8f8f8; /* putih abu2 lembut */
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .login-container {
            background: #fff;
            width: 340px;
            border-radius: 12px;
            box-shadow: 0px 6px 18px rgba(0,0,0,0.15);
            overflow: hidden;
            animation: fadeIn 0.6s ease-in-out;
        }

        .login-header {
            background: maroon;
            color: white;
            text-align: center;
            padding: 16px;
            font-size: 20px;
            font-weight: bold;
        }

        .login-form {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 25px;
        }

        .input-group {
            position: relative;
            width: 100%;
            margin-bottom: 16px;
        }

        .input-group input {
            width: 100%;
            padding: 10px 35px 10px 12px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 14px;
            outline: none;
            transition: 0.3s;
        }

        .input-group input:focus {
            border-color: maroon;
            box-shadow: 0px 0px 6px rgba(128,0,0,0.25);
        }

        .input-group span {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 16px;
            color: maroon;
        }

        .login-form button {
            width: 100%;
            padding: 12px;
            background: maroon;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            font-weight: bold;
            transition: 0.3s;
        }

        .login-form button:hover {
            background: #a10000;
        }

        .back-btn {
            margin-top: 12px;
            display: inline-block;
            text-decoration: none;
            color: maroon;
            font-size: 14px;
            font-weight: bold;
        }

        .back-btn:hover {
            text-decoration: underline;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-15px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">🔒 Login Dashboard</div>
        <form class="login-form" action="" method="post">
            <div class="input-group">
                <input type="text" name="username" placeholder="Username">
                <span>👤</span>
            </div>
            <div class="input-group">
                <input type="password" name="password" placeholder="Password">
                <span>🔑</span>
            </div>
            <button name="login">Login</button>
            <a href="index.php" class="back-btn">⬅ Kembali</a>
        </form>
    </div>
</body>
</html>

<?php
if(isset($_POST['login'])){
    $username=$_POST['username'];
    $password=$_POST['password'];
    $query=mysqli_query($koneksi,"SELECT * FROM users WHERE username='$username' AND password='$password'");
    $cek = mysqli_num_rows($query);
    if($cek>0){
        session_start();
        $_SESSION['status']="sukses";
        $_SESSION['username']=$username;
        header('location:index2.php');
    } else {
        echo "<script>alert('Username atau Password salah!');</script>";
    }
}
?>
