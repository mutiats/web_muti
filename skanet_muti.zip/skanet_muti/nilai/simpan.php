<?php
include "koneksi.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nis      = $_POST['nis'];
    $kd_mapel = $_POST['kd_mapel'];
    $nip      = $_POST['nip'];
    $nilai    = $_POST['nilai'];

    $sql = "INSERT INTO nilai (nis, nip, kd_mapel, nilai)
VALUES ('$nis', '$nip', '$kd_mapel', '$nilai')";
    $query = mysqli_query($koneksi, $sql);

    if ($query) {
        header("Location: index.php");
        exit;
    } else {
        echo "Query gagal: " . mysqli_error($koneksi);
    }
}
?>
