<?php
include "koneksi.php";

$id_nilai = $_GET['id_nilai']; // ambil ID dari URL

// ambil data nilai berdasarkan ID
$query = mysqli_query($koneksi, "SELECT * FROM nilai WHERE id_nilai='$id_nilai'");
$data = mysqli_fetch_assoc($query);

// ambil data untuk dropdown
$siswa = mysqli_query($koneksi, "SELECT * FROM siswa");
$mapel = mysqli_query($koneksi, "SELECT * FROM mapel");
$guru  = mysqli_query($koneksi, "SELECT * FROM guru");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Data Nilai</title>
  <style>
    body {
      font-family: "Segoe UI", Arial, sans-serif;
      background: #f3f0f0;
      margin: 0;
      padding: 40px;
      color: #333;
    }
    .form-container {
      max-width: 600px;
      margin: auto;
      background: #fff;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 6px 15px rgba(0,0,0,0.1);
    }
    h1 {
      text-align: center;
      color: maroon;
      margin-bottom: 25px;
    }
    label {
      display: block;
      margin-top: 12px;
      color: #444;
      font-weight: 500;
    }
    input, select {
      width: 100%;
      padding: 10px;
      margin-top: 6px;
      border-radius: 8px;
      border: 1px solid #ccc;
      font-size: 15px;
    }
    button {
      background: maroon;
      color: white;
      border: none;
      padding: 12px 18px;
      border-radius: 8px;
      cursor: pointer;
      font-size: 15px;
      margin-top: 20px;
      transition: 0.3s;
    }
    button:hover {
      background: #800000;
    }
    .back-btn {
      display: inline-block;
      background: #6c757d;
      color: #fff;
      padding: 10px 15px;
      border-radius: 8px;
      text-decoration: none;
      margin-top: 15px;
    }
    .back-btn:hover {
      background: #5a6268;
    }
  </style>
</head>
<body>

  <div class="form-container">
    <h1>📊 Edit Data Nilai</h1>
    <form action="update.php" method="POST">
      <label for="id_nilai">ID Nilai</label>
      <input type="text" name="id_nilai" id="id_nilai" value="<?php echo $data['id_nilai']; ?>" readonly>

      <label for="nis">NIS - Nama Siswa</label>
      <select name="nis" id="nis">
        <?php while($row = mysqli_fetch_array($siswa)) { ?>
          <option value="<?php echo $row['nis']; ?>" 
            <?php if($row['nis'] == $data['nis']) echo "selected"; ?>>
            <?php echo $row['nis']." - ".$row['nama']; ?>
          </option>
        <?php } ?>
      </select>

      <label for="kd_mapel">Kode Mapel - Nama Mapel</label>
      <select name="kd_mapel" id="kd_mapel">
        <?php while($row = mysqli_fetch_array($mapel)) { ?>
          <option value="<?php echo $row['kd_mapel']; ?>" 
            <?php if($row['kd_mapel'] == $data['kd_mapel']) echo "selected"; ?>>
            <?php echo $row['kd_mapel']." - ".$row['nama_mapel']; ?>
          </option>
        <?php } ?>
      </select>

      <label for="nip">NIP - Nama Guru</label>
      <select name="nip" id="nip">
        <?php while($row = mysqli_fetch_array($guru)) { ?>
          <option value="<?php echo $row['nip']; ?>" 
            <?php if($row['nip'] == $data['nip']) echo "selected"; ?>>
            <?php echo $row['nip']." - ".$row['nama']; ?>
          </option>
        <?php } ?>
      </select>

      <label for="nilai">Nilai</label>
      <input type="text" name="nilai" id="nilai" value="<?php echo $data['nilai']; ?>">

      <button type="submit">💾 Simpan</button>
    </form>
    <a href="index.php" class="back-btn">⬅ Kembali</a>
  </div>

</body>
</html>
