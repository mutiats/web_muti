<?php
include "koneksi.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Tambah Nilai</title>
  <style>
    body {
      font-family: "Segoe UI", Arial, sans-serif;
      background: #f3f0f0;
      margin: 0;
      padding: 40px;
      color: #333;
    }
    .container {
      max-width: 600px;
      margin: auto;
      background: #fff;
      padding: 25px 30px;
      border-radius: 12px;
      box-shadow: 0 6px 15px rgba(0,0,0,0.1);
    }
    h1 {
      text-align: center;
      color: maroon;
      margin-bottom: 25px;
      letter-spacing: 1px;
    }
    label {
      font-weight: 600;
      color: maroon;
      display: block;
      margin-top: 15px;
    }
    select, input {
      width: 100%;
      padding: 10px 12px;
      border: 1px solid #ccc;
      border-radius: 8px;
      margin-top: 6px;
      font-size: 15px;
    }
    button {
      margin-top: 25px;
      width: 100%;
      background: maroon;
      color: #fff;
      padding: 12px;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      cursor: pointer;
      transition: 0.3s;
    }
    button:hover {
      background: #800000;
    }
    .back {
      display: block;
      text-align: center;
      margin-top: 15px;
      color: maroon;
      text-decoration: none;
      font-weight: 500;
    }
    .back:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>➕ Tambah Data Nilai</h1>
    <form action="simpan.php" method="post">
      
      <label for="nis">Nama Siswa</label>
      <select name="nis" id="nis" required>
        <option value="">-- Pilih Siswa --</option>
        <?php
        $query = mysqli_query($koneksi, "SELECT * FROM siswa");
        while ($data = mysqli_fetch_array($query)) {
          echo "<option value='".$data['nis']."'>".$data['nama']."</option>";
        }
        ?>
      </select>

      <label for="kd_mapel">Mata Pelajaran</label>
      <select name="kd_mapel" id="kd_mapel" required>
        <option value="">-- Pilih Mapel --</option>
        <?php
        $query = mysqli_query($koneksi, "SELECT * FROM mapel");
        while ($data = mysqli_fetch_array($query)) {
          echo "<option value='".$data['kd_mapel']."'>".$data['nama_mapel']."</option>";
        }
        ?>
      </select>

      <label for="nip">Guru Pengampu</label>
      <select name="nip" id="nip" required>
        <option value="">-- Pilih Guru --</option>
        <?php
        $query = mysqli_query($koneksi, "SELECT * FROM guru");
        while ($data = mysqli_fetch_array($query)) {
          echo "<option value='".$data['nip']."'>".$data['nama']."</option>";
        }
        ?>
      </select>

      <label for="nilai">Nilai</label>
      <input type="text" name="nilai" id="nilai" required>

      <button type="submit">Simpan</button>
    </form>

    <a href="index.php" class="back">⬅ Kembali</a>
  </div>
</body>
</html>
