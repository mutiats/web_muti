<?php
include "koneksi.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_nilai = $_POST['id_nilai'];
    $nis      = $_POST['nis'];
    $kd_mapel = $_POST['kd_mapel'];
    $nip      = $_POST['nip'];
    $nilai    = $_POST['nilai'];

    $sql = "UPDATE nilai 
            SET nis='$nis',
                kd_mapel='$kd_mapel',
                nip='$nip',
                nilai='$nilai'
            WHERE id_nilai='$id_nilai'";

    $query = mysqli_query($koneksi, $sql);

    if ($query) {
        echo "Data berhasil diupdate!";
        header("Location: index.php");
        exit;
    } else {
        echo "Query gagal: " . mysqli_error($koneksi);
    }
}
?>
