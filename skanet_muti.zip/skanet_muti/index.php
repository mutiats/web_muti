<?php
session_start();
if($_SESSION['status']<>"sukses"){
    header('location:logout.php');
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Dashboard - Mumu Class</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Google Font -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">

  <!-- Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

  <style>
    * {
      box-sizing: border-box;
    }

    body {
      font-family: "Poppins", sans-serif;
      background: linear-gradient(180deg, #800000 0%, #a93226 100%);
      margin: 0;
      padding: 0;
      color: #333;
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .container {
      width: 90%;
      max-width: 850px;
      background: #fff;
      padding: 40px 30px 50px;
      border-radius: 20px;
      box-shadow: 0 8px 25px rgba(0,0,0,0.2);
      text-align: center;
      animation: fadeIn 0.6s ease-in-out;
    }

    @keyframes fadeIn {
      from {opacity: 0; transform: translateY(20px);}
      to {opacity: 1; transform: translateY(0);}
    }

    h1 {
      color: #800000;
      font-weight: 700;
      font-size: 2rem;
      margin-bottom: 25px;
    }

    .menu {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
      gap: 20px;
      margin-top: 20px;
    }

    .menu a {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      background: #800000;
      color: #fff;
      text-decoration: none;
      border-radius: 15px;
      padding: 25px 15px;
      font-weight: 500;
      font-size: 1rem;
      transition: all 0.3s ease;
      box-shadow: 0 3px 10px rgba(0,0,0,0.2);
    }

    .menu a:hover {
      background: #a93226;
      transform: translateY(-6px);
      box-shadow: 0 6px 15px rgba(0,0,0,0.3);
    }

    .menu a i {
      font-size: 2rem;
      margin-bottom: 10px;
    }

    .logout-btn {
      display: inline-block;
      margin-top: 40px;
      background: #a93226;
      color: #fff;
      padding: 12px 28px;
      border-radius: 10px;
      text-decoration: none;
      font-weight: 600;
      transition: 0.3s;
    }

    .logout-btn:hover {
      background: #ffb3b3;
      color: #800000;
    }

    footer {
      margin-top: 35px;
      color: #555;
      font-size: 0.9rem;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1><i class="bi bi-speedometer2"></i> Dashboard Mumu</h1>
    <div class="menu">
      <a href="siswa/index.php"><i class="bi bi-person-fill"></i> Data Siswa</a>
      <a href="guru/index.php"><i class="bi bi-mortarboard-fill"></i> Data Guru</a>
      <a href="mapel/index.php"><i class="bi bi-book-fill"></i> Data Mapel</a>
      <a href="nilai/index.php"><i class="bi bi-pencil-square"></i> Data Nilai</a>
    </div>

    <a href="logout.php" class="logout-btn">
      <i class="bi bi-box-arrow-right"></i> Logout
    </a>

    <footer>
      <p>© 2025 Mumu Class | SMK Negeri Takeran</p>
    </footer>
  </div>
</body>
</html>
