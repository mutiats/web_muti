<?php
include "../koneksi.php";
session_start();
if($_SESSION['status']<>"sukses"){
  header('location:../logout.php');
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Tambah Data Siswa</title>
  <style>
    body {
      font-family: "Segoe UI", Arial, sans-serif;
      background: #f3f0f0;
      margin: 0;
      padding: 40px;
      color: #333;
    }
    .container {
      max-width: 500px;
      margin: auto;
      background: #fff;
      padding: 30px 40px;
      border-radius: 12px;
      box-shadow: 0 6px 15px rgba(0,0,0,0.1);
    }
    h1 {
      text-align: center;
      color: maroon;
      margin-bottom: 25px;
      letter-spacing: 1px;
    }
    form {
      display: flex;
      flex-direction: column;
      gap: 15px;
    }
    label {
      font-weight: 600;
      margin-bottom: 5px;
    }
    input[type="text"] {
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 8px;
      font-size: 15px;
      transition: 0.3s;
    }
    input[type="text"]:focus {
      border-color: maroon;
      outline: none;
      box-shadow: 0 0 5px rgba(128, 0, 0, 0.3);
    }
    .btn {
      padding: 10px 16px;
      border: none;
      border-radius: 8px;
      font-size: 15px;
      color: #fff;
      cursor: pointer;
      transition: 0.3s;
    }
    .simpan {
      background: maroon;
    }
    .simpan:hover {
      background: #800000;
    }
    .kembali {
      background: #6c757d;
      text-decoration: none;
      text-align: center;
      display: inline-block;
      padding: 10px 16px;
      border-radius: 8px;
      color: #fff;
      transition: 0.3s;
    }
    .kembali:hover {
      background: #5a6268;
    }
    .btn-group {
      display: flex;
      justify-content: space-between;
      margin-top: 15px;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>➕ Tambah Data Siswa</h1>
    <form action="simpan.php" method="post">
      <div>
        <label for="nis">NIS :</label>
        <input type="text" name="nis" id="nis" required>
      </div>

      <div>
        <label for="nama">Nama :</label>
        <input type="text" name="nama" id="nama" required>
      </div>

      <div>
        <label for="alamat">Alamat :</label>
        <input type="text" name="alamat" id="alamat" required>
      </div>

      <div>
        <label for="kelas">Kelas :</label>
        <input type="text" name="kelas" id="kelas" required>
      </div>

      <div>
        <label for="je_ke">Je_ke :</label>
        <input type="text" name="je_ke" id="je_ke" required>
      </div>

      <div class="btn-group">
        <button type="submit" class="btn simpan">💾 Simpan</button>
        <a href="index.php" class="kembali">⬅ Kembali</a>
      </div>
    </form>
  </div>
</body>
</html>
