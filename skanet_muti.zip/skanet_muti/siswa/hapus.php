<?php
include "koneksi.php";

if (!isset($_GET['nis'])) {
    die("NIS tidak ditemukan");
}

$nis = $_GET['nis'];
$query = mysqli_query($koneksi, "DELETE FROM siswa WHERE nis='$nis'");

if ($query) {
    header("Location: index.php");
    exit;
} else {
    echo "Gagal hapus data: " . mysqli_error($koneksi);
}
?>
