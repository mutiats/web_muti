<?php
include "koneksi.php";

$nis    = $_POST['nis'];
$nama   = $_POST['nama'];
$alamat = $_POST['alamat'];
$kelas  = $_POST['kelas'];
$je_ke  = $_POST['je_ke'];

$query = mysqli_query($koneksi, 
    "INSERT INTO siswa (nis, nama, alamat, kelas, je_ke) 
     VALUES ('$nis','$nama','$alamat','$kelas','$je_ke')"
);

if ($query) {
    header("Location: index.php");
    exit;
} else {
    echo "Gagal simpan data: " . mysqli_error($koneksi);
}
?>
