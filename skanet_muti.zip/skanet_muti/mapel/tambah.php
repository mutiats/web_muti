<?php
include "koneksi.php";
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Tambah Data Mapel</title>
  <style>
    body {
      font-family: "Segoe UI", Arial, sans-serif;
      background: #f3f0f0;
      margin: 0;
      padding: 40px;
      color: #333;
    }
    .container {
      max-width: 500px;
      margin: auto;
      background: #fff;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 6px 15px rgba(0,0,0,0.1);
    }
    h1 {
      text-align: center;
      color: maroon;
      margin-bottom: 25px;
      letter-spacing: 1px;
    }
    label {
      font-weight: 600;
      color: #444;
      display: block;
      margin-bottom: 6px;
    }
    input[type="text"] {
      width: 100%;
      padding: 10px 12px;
      border: 1px solid #ccc;
      border-radius: 8px;
      margin-bottom: 15px;
      font-size: 15px;
      transition: 0.3s;
    }
    input[type="text"]:focus {
      border-color: maroon;
      outline: none;
      box-shadow: 0 0 5px rgba(128, 0, 0, 0.3);
    }
    .btn {
      display: inline-block;
      padding: 10px 18px;
      border-radius: 8px;
      text-decoration: none;
      color: #fff;
      border: none;
      font-size: 15px;
      cursor: pointer;
      transition: 0.3s;
    }
    .simpan {
      background: maroon;
      margin-right: 10px;
    }
    .simpan:hover {
      background: #800000;
    }
    .kembali {
      background: #6c757d;
      text-decoration: none;
    }
    .kembali:hover {
      background: #5a6268;
    }
    .button-container {
      text-align: center;
      margin-top: 10px;
    }
  </style>
</head>
<body>

  <div class="container">
    <h1>📝 Tambah Data Mapel</h1>
    <form action="simpan.php" method="post">
      <label for="kd_mapel">Kode Mapel :</label>
      <input type="text" id="kd_mapel" name="kd_mapel" required>

      <label for="nama_mapel">Nama Mapel :</label>
      <input type="text" id="nama_mapel" name="nama_mapel" required>

      <div class="button-container">
        <button type="submit" class="btn simpan">💾 Simpan</button>
        <a href="index.php" class="btn kembali">⬅ Kembali</a>
      </div>
    </form>
  </div>

</body>
</html>
