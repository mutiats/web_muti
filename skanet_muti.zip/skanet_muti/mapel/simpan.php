<?php
include "koneksi.php";

if (isset($_POST['kd_mapel']) && isset($_POST['nama_mapel'])) {
    $kd_mapel   = $_POST['kd_mapel'];
    $nama_mapel = $_POST['nama_mapel'];

    $query = mysqli_query($koneksi, "INSERT INTO mapel (kd_mapel, nama_mapel) VALUES ('$kd_mapel','$nama_mapel')");

    if ($query) {
        echo "<script>
                alert('Data mapel berhasil disimpan!');
                window.location.href='index.php';
              </script>";
    } else {
        echo "<script>
                alert('Gagal menyimpan data: " . mysqli_error($koneksi) . "');
                window.history.back();
              </script>";
    }
} else {
    echo "<script>
            alert('Form belum diisi dengan benar!');
            window.history.back();
          </script>";
}
?>
