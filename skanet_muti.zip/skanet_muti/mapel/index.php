<?php
include "../koneksi.php";
session_start();
if($_SESSION['status']<>"sukses"){
  header('location:../logout.php');
}
$query = mysqli_query($koneksi,"SELECT * FROM mapel");
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Data Mapel - Mumu Class</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Google Font & Icons -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

  <style>
    * {
      box-sizing: border-box;
    }

    body {
      font-family: "Poppins", sans-serif;
      background: linear-gradient(180deg, #800000 0%, #a93226 100%);
      margin: 0;
      padding: 40px 10px;
      color: #333;
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: flex-start;
    }

    .container {
      width: 95%;
      max-width: 900px;
      background: #fff;
      padding: 30px 40px;
      border-radius: 20px;
      box-shadow: 0 8px 25px rgba(0,0,0,0.15);
      animation: fadeIn 0.5s ease-in-out;
    }

    @keyframes fadeIn {
      from {opacity: 0; transform: translateY(20px);}
      to {opacity: 1; transform: translateY(0);}
    }

    h1 {
      text-align: center;
      color: #800000;
      margin-bottom: 30px;
      font-weight: 700;
      letter-spacing: 1px;
    }

    .actions {
      display: flex;
      justify-content: space-between;
      flex-wrap: wrap;
      margin-bottom: 20px;
    }

    .btn {
      display: inline-block;
      background: #800000;
      color: #fff;
      padding: 10px 20px;
      border-radius: 10px;
      text-decoration: none;
      font-weight: 500;
      transition: 0.3s;
      font-size: 15px;
    }

    .btn:hover {
      background: #a93226;
      transform: translateY(-2px);
      box-shadow: 0 3px 10px rgba(0,0,0,0.2);
    }

    .btn i {
      margin-right: 6px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      border-radius: 12px;
      overflow: hidden;
    }

    th, td {
      padding: 12px 15px;
      text-align: center;
      font-size: 15px;
    }

    th {
      background: #800000;
      color: #fff;
      font-weight: 600;
    }

    tr:nth-child(even) {
      background: #f8f4f4;
    }

    tr:hover {
      background: #f1dada;
    }

    .aksi a {
      margin: 0 5px;
      padding: 6px 12px;
      border-radius: 8px;
      text-decoration: none;
      color: #fff;
      font-size: 14px;
      transition: 0.3s;
      display: inline-block;
    }

    .edit { background: #28a745; }
    .edit:hover { background: #218838; }
    .hapus { background: #dc3545; }
    .hapus:hover { background: #b02a37; }

    footer {
      text-align: center;
      color: #666;
      margin-top: 25px;
      font-size: 0.9rem;
    }

    @media(max-width: 600px){
      th, td {
        font-size: 13px;
        padding: 8px;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <h1><i class="bi bi-book-half"></i> Data Mapel</h1>

    <div class="actions">
      <a href="tambah.php" class="btn"><i class="bi bi-plus-circle"></i> Tambah Data</a>
      <a href="../index2.php" class="btn"><i class="bi bi-arrow-left-circle"></i> Kembali</a>
    </div>

    <table>
      <tr>
        <th>Kode Mapel</th>
        <th>Nama Mapel</th>
        <th>Aksi</th>
      </tr>
      <?php while($data = mysqli_fetch_array($query)) { ?>
      <tr>
        <td><?= $data['kd_mapel']; ?></td>
        <td><?= $data['nama_mapel']; ?></td>
        <td class="aksi">
          <a href="edit.php?kd_mapel=<?= $data['kd_mapel']; ?>" class="edit"><i class="bi bi-pencil-square"></i> Edit</a>
          <a href="hapus.php?kd_mapel=<?= $data['kd_mapel']; ?>" class="hapus" onclick="return confirm('Yakin hapus data ini?');"><i class="bi bi-trash3"></i> Hapus</a>
        </td>
      </tr>
      <?php } ?>
    </table>

    <footer>
      © 2025 Mumu Class | SMK Negeri Takeran
    </footer>
  </div>
</body>
</html>
