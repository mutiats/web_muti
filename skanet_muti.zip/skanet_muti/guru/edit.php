
<?php
include "koneksi.php";
$nip = $_GET['nip'];
$query = mysqli_query($koneksi,"SELECT * FROM guru WHERE nip='$nip'");
$data = mysqli_fetch_array($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Data Guru</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: #f3f0f0;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }
    .form-container {
      background: #fff;
      padding: 35px 40px;
      border-radius: 16px;
      box-shadow: 0 8px 20px rgba(0,0,0,0.15);
      width: 420px;
      animation: fadeIn 0.6s ease-in-out;
    }
    h1 {
      text-align: center;
      color: maroon;
      margin-bottom: 25px;
      font-size: 24px;
      border-bottom: 2px solid maroon;
      padding-bottom: 8px;
    }
    label {
      display: block;
      margin-bottom: 6px;
      font-weight: 600;
      color: #333;
    }
    input {
      width: 100%;
      padding: 10px 12px;
      margin-bottom: 18px;
      border: 1px solid #ccc;
      border-radius: 10px;
      font-size: 14px;
      outline: none;
      transition: 0.3s;
    }
    input:focus {
      border-color: maroon;
      box-shadow: 0px 0px 6px rgba(128,0,0,0.25);
    }
    button {
      width: 100%;
      padding: 12px;
      border: none;
      border-radius: 10px;
      background: maroon;
      color: #fff;
      font-size: 16px;
      font-weight: bold;
      cursor: pointer;
      transition: 0.3s;
    }
    button:hover {
      background: #a00000;
    }
    .back-btn {
      display: block;
      text-align: center;
      margin-top: 15px;
      text-decoration: none;
      color: maroon;
      font-weight: bold;
      transition: 0.3s;
    }
    .back-btn:hover {
      text-decoration: underline;
    }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(-15px); }
      to { opacity: 1; transform: translateY(0); }
    }
  </style>
</head>
<body>
  <div class="form-container">
    <h1>✏ Edit Data Guru</h1>
    <form action="update.php" method="POST">
      <label for="nip">NIP</label>
      <input type="text" name="nip" id="nip" value="<?php echo $data['nip']; ?>" readonly>

      <label for="nama">Nama</label>
      <input type="text" name="nama" id="nama" value="<?php echo $data['nama']; ?>">

      <label for="alamat">Alamat</label>
      <input type="text" name="alamat" id="alamat" value="<?php echo $data['alamat']; ?>">

      <label for="mapel">Mapel</label>
      <input type="text" name="mapel" id="mapel" value="<?php echo $data['mapel']; ?>">

      <button type="submit">💾 Simpan</button>
    </form>
    <a href="index.php" class="back-btn">⬅ Kembali</a>
  </div>
</body>
</html>
