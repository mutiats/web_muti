<?php
include "koneksi.php";
$nip=$_POST['nip'];
$nama=$_POST['nama'];
$alamat=$_POST['alamat'];
$mapel=$_POST['mapel'];
$query=mysqli_query($koneksi,"insert into guru(nip,nama,alamat,mapel) values('$nip','$nama','$alamat','$mapel')");
header('location:index.php')
?>