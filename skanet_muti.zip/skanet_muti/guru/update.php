<?php
include "koneksi.php";
$nip=$_POST['nip'];
$nama=$_POST['nama'];
$alamat=$_POST['alamat'];
$mapel=$_POST['mapel'];
$query=mysqli_query($koneksi,"update guru set nama='$nama',alamat='$alamat',mapel='$mapel' where nip='$nip'");
header('location:index.php');
?>