<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Tambah Data Guru</title>
  <style>
    body {
      font-family: "Segoe UI", Arial, sans-serif;
      background: #f3f0f0;
      margin: 0;
      padding: 40px;
      color: #333;
    }
    .container {
      max-width: 500px;
      margin: auto;
      background: #fff;
      padding: 30px 40px;
      border-radius: 12px;
      box-shadow: 0 6px 15px rgba(0,0,0,0.1);
    }
    h1 {
      text-align: center;
      color: maroon;
      margin-bottom: 25px;
      letter-spacing: 1px;
    }
    form {
      display: flex;
      flex-direction: column;
      gap: 15px;
    }
    label {
      font-weight: 600;
      margin-bottom: 5px;
      color: #444;
    }
    input {
      padding: 10px;
      border-radius: 8px;
      border: 1px solid #ccc;
      font-size: 15px;
      transition: 0.3s;
    }
    input:focus {
      outline: none;
      border-color: maroon;
      box-shadow: 0 0 5px rgba(128,0,0,0.4);
    }
    .btn {
      padding: 10px 18px;
      border-radius: 8px;
      border: none;
      background: maroon;
      color: #fff;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      transition: 0.3s;
    }
    .btn:hover {
      background: #800000;
    }
    .back {
      display: inline-block;
      margin-top: 20px;
      text-decoration: none;
      color: #fff;
      background: #6c757d;
      padding: 10px 18px;
      border-radius: 8px;
      transition: 0.3s;
    }
    .back:hover {
      background: #5a6268;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>➕ Tambah Data Guru</h1>
    <form action="simpan.php" method="POST">
      <label for="nip">NIP :</label>
      <input type="text" name="nip" id="nip" required>

      <label for="nama">Nama :</label>
      <input type="text" name="nama" id="nama" required>

      <label for="alamat">Alamat :</label>
      <input type="text" name="alamat" id="alamat" required>

      <label for="mapel">Mapel :</label>
      <input type="text" name="mapel" id="mapel" required>

      <button type="submit" class="btn">💾 Simpan</button>
    </form>

    <a href="index.php" class="back">⬅ Kembali</a>
  </div>
</body>
</html>
