<!doctype html>
<html lang="id">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Mumu Class - SMK Negeri Takeran</title>

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">

    <!-- AOS Animation -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

    <style>
      body {
        font-family: 'Poppins', sans-serif;
        background-color: #f9f9f9;
      }

      /* Navbar */
      .navbar {
        background-color: #800000 !important; /* Maroon */
        box-shadow: 0 3px 10px rgba(0,0,0,0.2);
      }
      .navbar-brand, .nav-link {
        color: #fff !important;
        font-weight: 500;
      }
      .nav-link:hover {
        color: #ffd1d1 !important;
      }

      /* Hero */
      .hero {
        background: linear-gradient(rgba(128,0,0,0.6), rgba(128,0,0,0.6)), url('assets/carousel/1.png') center/cover no-repeat;
        color: white;
        text-align: center;
        padding: 120px 20px;
      }
      .hero h1 {
        font-size: 3rem;
        font-weight: 700;
        text-shadow: 2px 2px 6px rgba(0,0,0,0.4);
      }
      .hero p {
        font-size: 1.2rem;
        margin-top: 10px;
      }

      /* Section title */
      .section-title {
        color: #800000;
        font-weight: 700;
        text-align: center;
        margin: 60px 0 30px;
        position: relative;
      }
      .section-title::after {
        content: "";
        display: block;
        width: 70px;
        height: 4px;
        background-color: #800000;
        margin: 10px auto 0;
        border-radius: 10px;
      }

      /* Carousel */
      .carousel-item img {
        width: 100%;
        height: 550px;
        object-fit: cover;
        border-radius: 15px;
      }

      /* Cards */
      .card {
        border: none;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
      }
      .card:hover {
        transform: translateY(-8px);
        box-shadow: 0 8px 20px rgba(0,0,0,0.15);
      }

      .card-title {
        color: #800000;
        font-weight: 700;
      }

      /* Footer */
      footer {
        background-color: #800000;
        color: white;
        text-align: center;
        padding: 20px 0;
        margin-top: 60px;
      }
    </style>
  </head>

  <body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
      <div class="container">
        <a class="navbar-brand fw-bold" href="#">Mumu Class</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item"><a class="nav-link active" href="index.php">Home</a></li>
            <li class="nav-item"><a class="nav-link" href="siswa/index.php">Siswa</a></li>
            <li class="nav-item"><a class="nav-link" href="guru/index.php">Guru</a></li>
            <li class="nav-item"><a class="nav-link" href="mapel/index.php">Mapel</a></li>
            <li class="nav-item"><a class="nav-link" href="nilai/index.php">Nilai</a></li>
            <li class="nav-item"><a class="nav-link" href="login.php">Logout</a></li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero" data-aos="fade-up">
      <div class="container">
        <h1>SMK Negeri Takeran</h1>
        <p>Mencetak Generasi Profesional dan Kreatif di Dunia Teknologi dan Kuliner</p>
      </div>
    </section>

    <!-- Carousel -->
    <div class="container my-5" data-aos="zoom-in">
      <div id="carouselExampleFade" class="carousel slide carousel-fade" data-bs-ride="carousel">
        <div class="carousel-inner rounded-4">
          <div class="carousel-item active">
            <img src="assets/carousel/1.png" class="d-block w-100" alt="SMK Takeran">
          </div>
          <div class="carousel-item">
            <img src="assets/carousel/rpl.jpeg" class="d-block w-100" alt="RPL">
          </div>
          <div class="carousel-item">
            <img src="assets/carousel/tkj.jpg" class="d-block w-100" alt="TKJ">
          </div>
          <div class="carousel-item">
            <img src="assets/carousel/kln.jpeg" class="d-block w-100" alt="Kuliner">
          </div>
          <div class="carousel-item">
            <img src="assets/carousel/dkv.jpeg" class="d-block w-100" alt="DKV">
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
          <span class="carousel-control-prev-icon"></span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
          <span class="carousel-control-next-icon"></span>
        </button>
      </div>
    </div>

    <!-- Jurusan Section -->
    <div class="container">
      <h2 class="section-title" data-aos="fade-up">Jurusan Unggulan</h2>
      <div class="row g-4">
        <div class="col-md-6 col-lg-3" data-aos="flip-left">
          <div class="card">
            <img src="assets/carousel/rpl.jpeg" class="card-img-top" alt="RPL">
            <div class="card-body text-center">
              <h5 class="card-title">Rekayasa Perangkat Lunak (RPL)</h5>
              <p class="card-text">Belajar membuat aplikasi, website, dan sistem digital dengan teknologi modern.</p>
            </div>
          </div>
        </div>

        <div class="col-md-6 col-lg-3" data-aos="flip-left">
          <div class="card">
            <img src="assets/carousel/tkj.jpg" class="card-img-top" alt="TKJ">
            <div class="card-body text-center">
              <h5 class="card-title">Teknik Komputer & Jaringan (TKJ)</h5>
              <p class="card-text">Menguasai instalasi jaringan, server, dan sistem keamanan komputer.</p>
            </div>
          </div>
        </div>

        <div class="col-md-6 col-lg-3" data-aos="flip-left">
          <div class="card">
            <img src="assets/carousel/kln.jpeg" class="card-img-top" alt="Kuliner">
            <div class="card-body text-center">
              <h5 class="card-title">Kuliner</h5>
              <p class="card-text">Mencetak calon chef profesional dengan kemampuan memasak dan tata boga.</p>
            </div>
          </div>
        </div>

        <div class="col-md-6 col-lg-3" data-aos="flip-left">
          <div class="card">
            <img src="assets/carousel/dkv.jpeg" class="card-img-top" alt="DKV">
            <div class="card-body text-center">
              <h5 class="card-title">Desain Komunikasi Visual (DKV)</h5>
              <p class="card-text">Mengembangkan kreativitas dalam desain grafis, animasi, dan multimedia.</p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Footer -->
    <footer>
      <p>© 2025 Mumu Class | SMK Negeri Takeran - Semua Jurusan</p>
    </footer>

    <!-- JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
      AOS.init({
        duration: 1000,
        once: true
      });
    </script>
  </body>
</html>
