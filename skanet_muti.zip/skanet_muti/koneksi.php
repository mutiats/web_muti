<?php
$koneksi=mysqli_connect("localhost","root","","skanet_muti");

?>